---
title: "Borrowers vs Lenders"
---
1.  [](/paydax-docs)

Borrowers vs Lenders
====================

[Borrowers](/paydax-docs/paydax-whitepaper-v6/borrowers-vs-lenders/borrowers)[Lenders (Supplying to Lending Pools)](/paydax-docs/paydax-whitepaper-v6/borrowers-vs-lenders/lenders-supplying-to-lending-pools)[Stability Pool Participants (A specific type of PDP Staker)](/paydax-docs/paydax-whitepaper-v6/borrowers-vs-lenders/stability-pool-participants-a-specific-type-of-pdprotocol-staker)
